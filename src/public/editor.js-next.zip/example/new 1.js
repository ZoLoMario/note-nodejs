  /**
   * Saving button
   */ var editor = new EditorJS({
  const saveButton = document.getElementById('saveButton'); /**
     * Create a holder for the Editor and pass its ID
  /** */
   * To initialize the Editor, create a new instance with configuration 
object holder : 'editorjs',
   * @see docs/installation.md for mode details
   */ /**
  var editor = new EditorJS({ * Available Tools list.
    /** * Pass Tool's class or Settings object for each Tool you want to 
use
     * Wrapper of Editor */
     */ tools: { ,
    holder: 'editorjs', /**
         * Each Tool is a Plugin. Pass them via 'class' option with 
necessary settings {@link docs/tools.md}
    /** */ /**
     * Tools list header: { * Previously saved data that should be 
rendered
     */ class: Header, */
    tools: { inlineToolbar: ['marker', 'link'], data: {}
      paragraph: { config: {});
        config: { placeholder: 'Header'
          placeholder: "Enter something" },
        }          shortcut: 'CMD+SHIFT+H' ,
      }, /**
      /** * Or pass class directly without any configuration
       * Each Tool is a Plugin. Pass them via 'class' option with 
necessary settings {@link docs/tools.md} */
       */ image: SimpleImage,
      header: { list: {
        class: Header, class: List,
        inlineToolbar: ['link'], inlineToolbar: true,
        config: { shortcut: 'CMD+SHIFT+L'
          placeholder: 'Header' },
        }, checklist: {
        shortcut: 'CMD+SHIFT+H' class: Checklist,
      }, inlineToolbar: true,
        },
      /** quote: {
       * Or pass class directly without any configuration class: Quote,
       */ inlineToolbar: true,
      image: ImageTool, config: {
            quotePlaceholder: 'Enter a quote',
      list: { captionPlaceholder: 'Quote\'s author',
        class: List, },
        inlineToolbar: true, shortcut: 'CMD+SHIFT+O'
        shortcut: 'CMD+SHIFT+L' },
      }, warning: Warning,
        marker: {
      checklist: { class: Marker,
        class: Checklist, shortcut: 'CMD+SHIFT+M'
        inlineToolbar: true, },
      }, code: {
          class: CodeTool,
      quote: { shortcut: 'CMD+SHIFT+C'
        class: Quote, },
        inlineToolbar: true, delimiter: Delimiter,
        config: { inlineCode: {
          quotePlaceholder: 'Enter a quote', class: InlineCode,
          captionPlaceholder: 'Quote\'s author', shortcut: 'CMD+SHIFT+C'
        }, },
        shortcut: 'CMD+SHIFT+O' linkTool: LinkTool,
      }, raw: RawTool,
       
      warning: Warning,
      marker: {
        class: Marker,
        shortcut: 'CMD+SHIFT+M'
      },
      code: {
        class: CodeTool,
        shortcut: 'CMD+SHIFT+C'
      },
      delimiter: Delimiter,
      inlineCode: {
        class: InlineCode,
        shortcut: 'CMD+SHIFT+C'
      },
      linkTool: LinkTool,
      embed: Embed,
      table: {
        class: Table,
        inlineToolbar: true,
        shortcut: 'CMD+ALT+T'
      },
    },
    /**
     * To provide localization of the editor.js you need to provide 
'i18n' option with 'messages' dictionary:
     *
     * 1. At the 'ui' section of 'messages' there are translations for 
the internal editor.js UI elements.
     * You can create or find/download a dictionary for your language
     *
     * 2. As long as tools list is a user-specific thing (we do not know 
which tools you use and under which names),
     * so we can't provide a ready-to-use tool names dictionary.
     * There is a 'toolNames' section for that reason. Put translations 
for the names of your tools there.
     *
     * 3. Also, the UI of the tools you use is also invisible to 
editor.js core.
     * To pass translations for specific tools (that supports I18n API), 
there are 'tools' and 'blockTunes' section.
     * Pass dictionaries for specific plugins through them.
     */
    i18n: {
      /**
       * @type {I18nDictionary}
       */
      messages: {
        /**
         * Other below: translation of different UI components of the 
editor.js core
         */
        "ui": {
          "blockTunes": {
            "toggler": {
              "Click to tune": "Нажмите, чтобы настроить",
              "or drag to move": "или перетащите"
            },
          },
          "inlineToolbar": {
            "converter": {
              "Convert to": "Конвертировать в"
            }
          },
          "toolbar": {
            "toolbox": {
              "Add": "Добавить"
            }
          }
        },
        /**
         * Section for translation Tool Names: both block and inline 
tools
         */
        "toolNames": {
          "Text": "Параграф",
          "Heading": "Заголовок",
          "List": "Список",
          "Warning": "Примечание",
          "Checklist": "Чеклист",
          "Quote": "Цитата",
          "Code": "Код",
          "Delimiter": "Разделитель",
          "Raw HTML": "HTML-фрагмент",
          "Table": "Таблица",
          "Link": "Ссылка",
          "Marker": "Маркер",
          "Bold": "Полужирный",
          "Italic": "Курсив",
          "InlineCode": "Моноширинный",
          "Image": "Картинка"
        },
        /**
         * Section for passing translations to the external tools 
classes
         */
        "tools": {
          /**
           * Each subsection is the i18n dictionary that will be passed 
to the corresponded plugin
           * The name of a plugin should be equal the name you specify 
in the 'tool' section for that plugin
           */
          "warning": { // <-- 'Warning' tool will accept this dictionary 
section
            "Title": "Название",
            "Message": "Сообщение",
          },
          /**
           * Link is the internal Inline Tool
           */
          "link": {
            "Add a link": "Вставьте ссылку"
          },
          /**
           * The "stub" is an internal block tool, used to fit blocks 
that does not have the corresponded plugin
           */
          "stub": {
            'The block can not be displayed correctly.': 'Блок не может 
быть отображен'
          },
          "image": {
            "Caption": "Подпись",
            "Select an Image": "Выберите файл",
            "With border": "Добавить рамку",
            "Stretch image": "Растянуть",
            "With background": "Добавить подложку",
          },
          "code": {
            "Enter a code": "Код",
          },
          "linkTool": {
            "Link": "Ссылка",
            "Couldn't fetch the link data": "Не удалось получить 
данные",
            "Couldn't get this link data, try the other one": "Не 
удалось получить данные по ссылке, попробуйте другую",
            "Wrong response format from the server": "Неполадки на 
сервере",
          },
          "header": {
            "Header": "Заголовок",
          },
          "paragraph": {
            "Enter something": "Введите текст"
          },
          "list": {
            "Ordered": "Нумерованный",
            "Unordered": "Маркированный",
          }
        },
        /**
         * Section allows to translate Block Tunes
         */
        "blockTunes": {
          /**
           * Each subsection is the i18n dictionary that will be passed 
to the corresponded Block Tune plugin
           * The name of a plugin should be equal the name you specify 
in the 'tunes' section for that plugin
           *
           * Also, there are few internal block tunes: "delete", 
"moveUp" and "moveDown"
           */
          "delete": {
            "Delete": "Удалить"
          },
          "moveUp": {
            "Move up": "Переместить вверх"
          },
          "moveDown": {
            "Move down": "Переместить вниз"
          }
        },
      }
    },
    /**
     * Initial Editor data
     */
    data: {
      blocks: [
        {
          type: "header",
          data: {
            text: "Editor.js",
            level: 2
          }
        },
        {
          type : 'paragraph',
          data : {
            text : 'Hey. Meet the new Editor. On this page you can see 
it in action — try to edit this text. Source code of the page contains 
the example of connection and configuration.'
          }
        },
        {
          type: "header",
          data: {
            text: "Key features",
            level: 3
          }
        },
        {
          type : 'list',
          data : {
            items : [
              'It is a block-styled editor',
              'It returns clean data output in JSON',
              'Designed to be extendable and pluggable with a simple 
API',
            ],
            style: 'unordered'
          }
        },
        {
          type: "header",
          data: {
            text: "What does it mean «block-styled editor»",
            level: 3
          }
        },
        {
          type : 'paragraph',
          data : {
            text : 'Workspace in classic editors is made of a single 
contenteditable element, used to create different HTML markups. 
Editor.js <mark class=\"cdx-marker\">workspace consists of separate 
Blocks: paragraphs, headings, images, lists, quotes, etc</mark>. Each of 
them is an independent contenteditable element (or more complex 
structure) provided by Plugin and united by Editor\'s Core.'
          }
        },
        {
          type : 'paragraph',
          data : {
            text : `There are dozens of <a 
href="https://github.com/editor-js">ready-to-use Blocks</a> and the <a 
href="https://editorjs.io/creating-a-block-tool">simple API</a> for 
creation any Block you need. For example, you can implement Blocks for 
Tweets, Instagram posts, surveys and polls, CTA-buttons and even games.`
          }
        },
        {
          type: "header",
          data: {
            text: "What does it mean clean data output",
            level: 3
          }
        },
        {
          type : 'paragraph',
          data : {
            text : 'Classic WYSIWYG-editors produce raw HTML-markup with 
both content data and content appearance. On the contrary, Editor.js 
outputs JSON object with data of each Block. You can see an example 
below'
          }
        },
        {
          type : 'paragraph',
          data : {
            text : `Given data can be used as you want: render with HTML 
for <code class="inline-code">Web clients</code>, render natively for 
<code class="inline-code">mobile apps</code>, create markup for <code 
class="inline-code">Facebook Instant Articles</code> or <code 
class="inline-code">Google AMP</code>, generate an <code 
class="inline-code">audio version</code> and so on.`
          }
        },
        {
          type : 'paragraph',
          data : {
            text : 'Clean data is useful to sanitize, validate and 
process on the backend.'
          }
        },
        {
          type : 'delimiter',
          data : {}
        },
        {
          type : 'paragraph',
          data : {
            text : 'We have been working on this project more than three 
years. Several large media projects help us to test and debug the 
Editor, to make its core more stable. At the same time we significantly 
improved the API. Now, it can be used to create any plugin for any task. 
Hope you enjoy. 😏'
          }
        },
        {
          type: 'image',
          data: {
            file : {
              url: 'assets/codex2x.png',
            },
            caption: '',
            stretched: false,
            withBorder: true,
            withBackground: false,
          }
        },
      ]
    },
    onReady: function(){
      saveButton.click();
    },
  });
  /**
   * Saving example
   */
  saveButton.addEventListener('click', function () {
    editor.save().then((savedData) => {
      cPreview.show(savedData, document.getElementById("output"));
    });
  });